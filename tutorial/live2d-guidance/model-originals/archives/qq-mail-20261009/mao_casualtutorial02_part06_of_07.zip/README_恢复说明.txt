Live2D 官方原始模型邮件分卷恢复说明

模型：mao_casualtutorial02.zip
共 7 个分卷。把这个模型每封邮件的 ZIP 附件解压到同一个文件夹。

Windows：在该文件夹的地址栏输入 cmd，按回车，再复制下面一整行命令并按回车。

copy /b mao_casualtutorial02.part001.bin+mao_casualtutorial02.part002.bin+mao_casualtutorial02.part003.bin+mao_casualtutorial02.part004.bin+mao_casualtutorial02.part005.bin+mao_casualtutorial02.part006.bin+mao_casualtutorial02.part007.bin mao_casualtutorial02.zip

命令完成后，解压恢复的原始 ZIP。官方文件及许可没有修改，请遵守其使用条款。

可选完整性核验：
certutil -hashfile mao_casualtutorial02.zip SHA256
预期：50d34c9831cd61041c742eb1dd380ba1b856f96ed69405ba430d7ca20008042d
