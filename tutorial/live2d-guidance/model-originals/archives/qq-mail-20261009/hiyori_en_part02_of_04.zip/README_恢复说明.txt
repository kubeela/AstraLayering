Live2D 官方原始模型邮件分卷恢复说明

模型：hiyori_en.zip
共 4 个分卷。把这个模型每封邮件的 ZIP 附件解压到同一个文件夹。

Windows：在该文件夹的地址栏输入 cmd，按回车，再复制下面一整行命令并按回车。

copy /b hiyori_en.part001.bin+hiyori_en.part002.bin+hiyori_en.part003.bin+hiyori_en.part004.bin hiyori_en.zip

命令完成后，解压恢复的原始 ZIP。官方文件及许可没有修改，请遵守其使用条款。

可选完整性核验：
certutil -hashfile hiyori_en.zip SHA256
预期：1e4254d561f2a151562aa67036d78e17e4ffee08869b8ce10ab6052a05e2b3a4
