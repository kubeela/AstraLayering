Live2D 官方原始模型邮件分卷恢复说明

模型：natori_en.zip
共 3 个分卷。把这个模型每封邮件的 ZIP 附件解压到同一个文件夹。

Windows：在该文件夹的地址栏输入 cmd，按回车，再复制下面一整行命令并按回车。

copy /b natori_en.part001.bin+natori_en.part002.bin+natori_en.part003.bin natori_en.zip

命令完成后，解压恢复的原始 ZIP。官方文件及许可没有修改，请遵守其使用条款。

可选完整性核验：
certutil -hashfile natori_en.zip SHA256
预期：e16660ca073498884363613a881b04d69616a2bc09523667dc5d07b6e3db2d9f
