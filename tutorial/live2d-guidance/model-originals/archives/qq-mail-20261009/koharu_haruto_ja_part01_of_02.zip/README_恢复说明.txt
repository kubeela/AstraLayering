Live2D 官方原始模型邮件分卷恢复说明

模型：koharu_haruto_ja.zip
共 2 个分卷。把这个模型每封邮件的 ZIP 附件解压到同一个文件夹。

Windows：在该文件夹的地址栏输入 cmd，按回车，再复制下面一整行命令并按回车。

copy /b koharu_haruto_ja.part001.bin+koharu_haruto_ja.part002.bin koharu_haruto_ja.zip

命令完成后，解压恢复的原始 ZIP。官方文件及许可没有修改，请遵守其使用条款。

可选完整性核验：
certutil -hashfile koharu_haruto_ja.zip SHA256
预期：a0f677361ea94d8266e3c195ecdc6251e9e49529174315af0640e8eb5d170594
