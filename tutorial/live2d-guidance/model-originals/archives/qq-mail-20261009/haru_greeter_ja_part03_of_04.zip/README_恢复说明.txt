Live2D 官方原始模型邮件分卷恢复说明

模型：haru_greeter_ja.zip
共 4 个分卷。把这个模型每封邮件的 ZIP 附件解压到同一个文件夹。

Windows：在该文件夹的地址栏输入 cmd，按回车，再复制下面一整行命令并按回车。

copy /b haru_greeter_ja.part001.bin+haru_greeter_ja.part002.bin+haru_greeter_ja.part003.bin+haru_greeter_ja.part004.bin haru_greeter_ja.zip

命令完成后，解压恢复的原始 ZIP。官方文件及许可没有修改，请遵守其使用条款。

可选完整性核验：
certutil -hashfile haru_greeter_ja.zip SHA256
预期：3db5c9180fc8446f7d92eee13ea33f584e5d1308e101d7afa4fe3b037a0ed94e
