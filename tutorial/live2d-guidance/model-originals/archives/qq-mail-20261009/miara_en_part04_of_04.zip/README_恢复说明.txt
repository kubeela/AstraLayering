Live2D 官方原始模型邮件分卷恢复说明

模型：miara_en.zip
共 4 个分卷。把这个模型每封邮件的 ZIP 附件解压到同一个文件夹。

Windows：在该文件夹的地址栏输入 cmd，按回车，再复制下面一整行命令并按回车。

copy /b miara_en.part001.bin+miara_en.part002.bin+miara_en.part003.bin+miara_en.part004.bin miara_en.zip

命令完成后，解压恢复的原始 ZIP。官方文件及许可没有修改，请遵守其使用条款。

可选完整性核验：
certutil -hashfile miara_en.zip SHA256
预期：021f44d062d7cc1cbe6ac13e25ef7e1b981db187b8b5c4af521f2cba3613d9a4
